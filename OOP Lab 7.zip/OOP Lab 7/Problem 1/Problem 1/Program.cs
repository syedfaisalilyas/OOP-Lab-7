﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Problem_1.BL;

namespace Problem_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*    DayScholar std = new DayScholar();
                std.setname("Ahmad");
                std.setbusno(1);
                Console.WriteLine(std.getname() + "is Allocated Bus " + std.getBUSNo());
                Console.ReadLine();*/

            Hostelite std = new Hostelite();
            std.setname("Jaffer");
            std.setRoomNo(12);
            Console.WriteLine(std.getname() + " is Allocated Room " + std.getRoomNo());
            Console.ReadKey();
        }
    }
}
