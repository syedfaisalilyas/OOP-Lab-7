﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1.BL
{
    class DayScholar : Student
    {
        private string PickupPoint;
        private int BUsNo;
        private float PickupDistance;

        public int getBUSNo()
        {
            return BUsNo;
        }

        public void setbusno(int BUsNo)
        {
            this.BUsNo = BUsNo;
        }
        public float getBusFees()
        {
            float fees = 0.0F;
            return fees;
        }
    }
}
