﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1.BL
{
    class Student
    {
        protected private string name;
        protected private string session;
        protected private bool isDayScholar;
        protected private int EntryTestMarks;
        protected private int HSMarks;

        public string getname()
        {
            return name;
        }
        public void setname(string name)
        {
            this.name = name;
        }
        public float calculatemerit()
        {
            float merit = 0.0F;
            return merit;
        }
    }
}
