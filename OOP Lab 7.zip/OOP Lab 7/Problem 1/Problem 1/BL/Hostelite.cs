﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1.BL
{
    class Hostelite : Student
    {
        private int RoomNumber;
        private bool isFridgeAvailable;
        private bool isInternetAvailable;

        public int getRoomNo()
        {
            return RoomNumber;
        }

        public void setRoomNo(int RoomNumber)
        {
            this.RoomNumber = RoomNumber;
        }
        public float getHostelFee()
        {
            float fees= 0.0F;
            return fees;
        }
    }
}
