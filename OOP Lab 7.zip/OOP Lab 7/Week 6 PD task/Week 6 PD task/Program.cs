﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Week_6_PD_task.BL;

namespace Week_6_PD_task
{
    class Program
    {
        static void Main(string[] args)
        {
            int option = 0;
            do
            {
                Console.WriteLine("Press 1 to play GAME: ");
                Console.WriteLine("Press 2 to play EXIT: ");
                option = int.Parse(Console.ReadLine());
                Console.Clear();

                if (option == 1)
                {
                    bool gamerunning = true;
                    int score = 0;
                    Deck obj = new Deck();

                    obj.shuffle();

                    Card c1 = obj.dealCards();

                    while (gamerunning)
                    {
                        int remain_check = obj.cardsLeft();
                        Card c2 = obj.dealCards();
                        Console.WriteLine("**********************************");
                        Console.WriteLine(c1.ToString());
                        Console.WriteLine("");
                        Console.WriteLine("Remaining Cards ****:" + remain_check);
                        Console.WriteLine("Enter 1 if next card is higher:");
                        Console.WriteLine("Enter 2 if next card is lower:");

                        int card_check = int.Parse(Console.ReadLine());
                        Console.Clear();

                        if (card_check == 1)
                        {
                            if (c1.getvalue() >= c2.getvalue())
                            {
                                score++;
                                c1 = c2;
                            }
                            else
                            {
                                gamerunning = false;
                                Console.WriteLine("Sorry You Lose! Press any key to continue .");
                                Console.WriteLine("The Card was: " + c2.ToString());
                                Console.WriteLine("Your Score is:" + score);
                                Console.ReadKey();
                                Console.Clear();
                            }
                        }
                        if (card_check == 2)
                        {
                            if (c1.getvalue() <= c2.getvalue())
                            {
                                score++;
                                c1 = c2;
                            }
                            else
                            {
                                gamerunning = false;
                                Console.WriteLine("Sorry You Lose! Press any key to continue .");
                                Console.WriteLine("The Card was: " + c2.ToString());
                                Console.WriteLine("Your Score is:" + score);
                                Console.ReadKey();
                                Console.Clear();
                            }
                        }

                        if (obj.cardsLeft() == 0 || c2 == null)
                        {
                            gamerunning = false;
                            Console.WriteLine("Congrats! You have scored maximum.");
                            Console.ReadKey();
                            Console.Clear();
                            break;
                        }
                    }


                }
            } while (option != 2);


        }
    }
}
