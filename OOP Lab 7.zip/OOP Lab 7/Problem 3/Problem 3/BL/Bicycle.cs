﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_3.BL
{
    class Bicycle
    {
       private  int cadence;
       private int gear;
       private int speed;

        public Bicycle(int cadence, int speed, int gear)
        {
            this.cadence = cadence;
            this.gear = gear;
            this.speed = speed;
        }

        public void setCadence(int cadence)
        {
            this.cadence = cadence;
        }

        public void setgear(int gear)
        {
            this.gear = gear;
        }

        public void applybreak(int decrement)
        {
           speed = speed - decrement;
        }

        public void speedUp(int increment)
        {
            speed = speed + increment;
        }
    }
}
