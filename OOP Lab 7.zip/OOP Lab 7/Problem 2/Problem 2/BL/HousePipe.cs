﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2.BL
{
    class HousePipe
    {
        private string Quality;
        private string shape;
        private double diameter;
        private double waterFlowRate;

    }
}
