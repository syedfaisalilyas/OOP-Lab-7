﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2.BL
{
    class FireTruck
    {
       private Ladder L;
       private HousePipe H;
       private Person P;
    }
}
